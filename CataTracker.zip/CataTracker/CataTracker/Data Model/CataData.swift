//
//  Data.swift
//  CataTracker
//
//  Created by Martin Thomas on 7/28/19.
//  Copyright © 2019 Martin Thomas. All rights reserved.
//

import Foundation

class CataData: Codable {
    static var catagoryModels = [CatagoryModel]()
}
